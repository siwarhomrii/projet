import { CartItem } from "./cartItem";

export class Cart {
    public items:CartItem[]=[];
    public totalPrice:number=0;
}
