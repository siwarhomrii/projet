import { Comments } from "./comments";
export class Sweet {
    public id: number;
    public name: string;
    public photo: string;
    public price: number;
    public favorite: boolean;
    public date_creation: Date;
    public category:string;
    public comments?: Comments[];
    public quantite: number;
    constructor(
        id: number,
        name: string,
        photo: string,
        price: number,
        favorite: boolean,
        date_creation: Date,
        category:string,
        quantite: number
    ) {
        this.id = id;
        this.name = name;
        this.photo = photo;
        this.price = price;
        this.favorite = favorite;
        this.date_creation = date_creation;
        this.category=category;
        this.comments = [];
        this.quantite = quantite;
    }
}