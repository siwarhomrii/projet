import { Sweet } from './sweet';

describe('Sweet', () => {
  it('should create an instance', () => {
    expect(new Sweet()).toBeTruthy();
  });
});
