import { Component, inject, OnInit } from '@angular/core';
import { SweetService } from '../../../services/sweet.service';
import { Sweet } from '../../../models/sweet';
import { SweetItemComponent } from '../sweet-item/sweet-item.component';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-sweet-list',
  standalone: true,
  imports: [SweetItemComponent,RouterLink],
  templateUrl: './sweet-list.component.html',
  styleUrl: './sweet-list.component.css'
})
export class SweetListComponent implements OnInit {
  sweets: Sweet[] = [];
  private readonly sweetservice:SweetService=inject(SweetService);
  ngOnInit(): void {
    this.sweetservice.getSweets().subscribe(
      data=>this.sweets=data
    )
  }
}
