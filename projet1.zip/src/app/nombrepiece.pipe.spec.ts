import { NombrepiecePipe } from './nombrepiece.pipe';

describe('NombrepiecePipe', () => {
  it('create an instance', () => {
    const pipe = new NombrepiecePipe();
    expect(pipe).toBeTruthy();
  });
});
